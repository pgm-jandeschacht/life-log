import { createContext, useContext, useState } from 'react';

const FamilyMemberContext = createContext();
const useFamilyMemberContext = () => useContext(FamilyMemberContext);

const FamilyMemberProvider = ({ children }: any) => {
    const [ familyMember, setFamilyMember ] = useState(null);

    const handleFamilyMemberChange = ( fm: any ) => {
        setFamilyMember(fm);
    };

    return (
        <FamilyMemberContext.Provider value={{familyMember, handleFamilyMemberChange}}>
            {children}
        </FamilyMemberContext.Provider>
    )
}

export {
    FamilyMemberContext,
    FamilyMemberProvider,
    useFamilyMemberContext,
}