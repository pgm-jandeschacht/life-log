import React from 'react';
import DayList from './DayList';
import styled from 'styled-components';

import { useQuery } from "@apollo/client";
import { GET_FAMILYRELATIONS_BY_FAMILYMEMBER_ID } from '../../graphql/familyMembers';

import { FamilyRelationsData } from '../../interfaces'
import _ from 'lodash';


const StyledUl = styled.ul`
    display: flex;
    flex-direction: column;
`

const FamilyList = () => {
    // agenda.map(agendaItem => console.log(agendaItem.id))
    
    const familyMemberId = localStorage.getItem('familyMemberId') || '';

    const { data, loading, error } = useQuery<FamilyRelationsData >(GET_FAMILYRELATIONS_BY_FAMILYMEMBER_ID, {
        variables: {
            id: parseInt(familyMemberId)
        }
    });

    if(loading) return <p>"loading ..."</p>;
    if(error) return <p>"ERRRORRR!!"</p>;
    //data?.familyMemberById.agendaItems
    const agendaItems = data?.familyMemberById.agendaItems || [];
    const sortedAgendaItems = _.sortBy(agendaItems, ['date']);
    const reverseAgenda = sortedAgendaItems.reverse();
    // const sortedAgendaItems = _.groupBy(agendaItems, 'date');
    // console.log(sortedAgendaItems['2021-10-27T18:48:22.281Z'])
    return (
        <StyledUl>
            <ul>
            {  data.familyRelationsByFamilyMemberId.map(familyRelations => (
                <li>
                    </li>
            )) }
            </ul>
        </StyledUl>
    )
}

export default FamilyList;
